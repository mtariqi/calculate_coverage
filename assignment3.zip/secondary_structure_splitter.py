# secondary_structure_splitter.py

import argparse
import sys

def get_filehandle(file_name, mode):
    try:
        return open(file_name, mode)
    except OSError as e:
        raise OSError(f"Cannot open file {file_name}: {e}")

def get_fasta_lists(fh):
    headers = []
    sequences = []
    current_seq = ''
    for line in fh:
        line = line.strip()
        if line.startswith('>'):
            headers.append(line)
            if current_seq:
                sequences.append(current_seq)
                current_seq = ''
        else:
            current_seq += line
    if current_seq:
        sequences.append(current_seq)
    return headers, sequences

def _verify_lists(headers, sequences):
    if len(headers) != len(sequences):
        sys.exit("Header and sequence lists are not the same length")

def main():
    parser = argparse.ArgumentParser(description="Split FASTA file into sequence and secondary structure")
    parser.add_argument('-i', '--infile', required=True, help="Path to input FASTA file")
    args = parser.parse_args()

    fh_in = get_filehandle(args.infile, 'r')
    headers, sequences = get_fasta_lists(fh_in)
    _verify_lists(headers, sequences)
    fh_in.close()

if __name__ == '__main__':
    main()
