# nt_fasta_stats.py

import argparse
import sys

def get_filehandle(file_name, mode):
    try:
        return open(file_name, mode)
    except OSError as e:
        raise OSError(f"Cannot open file {file_name}: {e}")

def get_fasta_lists(fh):
    headers = []
    sequences = []
    current_seq = ''
    for line in fh:
        line = line.strip()
        if line.startswith('>'):
            headers.append(line)
            if current_seq:
                sequences.append(current_seq)
                current_seq = ''
        else:
            current_seq += line
    if current_seq:
        sequences.append(current_seq)
    return headers, sequences

def _verify_lists(headers, sequences):
    if len(headers) != len(sequences):
        sys.exit("Header and sequence lists are not the same length")

def _get_num_nucleotides(nt, seq):
    if nt not in "ACGTN":
        sys.exit("Did not code this condition")
    return seq.upper().count(nt)

def _get_ncbi_accession(header):
    return header.strip().split()[0][1:]

def output_results_to_files(headers, sequences, fh_out):
    _verify_lists(headers, sequences)
    fh_out.write("Number\tAccession\tA's\tG's\tC's\tT's\tN's\tLength\tGC%\n")
    for idx, (header, seq) in enumerate(zip(headers, sequences), 1):
        a = _get_num_nucleotides('A', seq)
        g = _get_num_nucleotides('G', seq)
        c = _get_num_nucleotides('C', seq)
        t = _get_num_nucleotides('T', seq)
        n = _get_num_nucleotides('N', seq)
        length = len(seq)
        gc_percent = round(((g + c) / length) * 100, 1) if length > 0 else 0
        accession = _get_ncbi_accession(header)
        fh_out.write(f"{idx}\t{accession}\t{a}\t{g}\t{c}\t{t}\t{n}\t{length}\t{gc_percent}\n")

def main():
    parser = argparse.ArgumentParser(description="Provide a FASTA file to generate nucleotide statistics")
    parser.add_argument('-i', '--infile', required=True, help="Path to file to open")
    parser.add_argument('-o', '--outfile', required=True, help="Path to file to write")
    args = parser.parse_args()

    fh_in = get_filehandle(args.infile, 'r')
    fh_out = get_filehandle(args.outfile, 'w')
    headers, sequences = get_fasta_lists(fh_in)
    output_results_to_files(headers, sequences, fh_out)
    fh_in.close()
    fh_out.close()

if __name__ == '__main__':
    main()
