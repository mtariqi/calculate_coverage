# Rubric Checklist

- [x] argparse used
- [x] unit tests written
- [x] coverage checked
...