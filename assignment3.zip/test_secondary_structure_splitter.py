import pytest
from secondary_structure_splitter import get_filehandle, _verify_lists

def test_get_filehandle_wrong_mode():
    with pytest.raises(ValueError):
        get_filehandle("somefile.txt", "rrr")

def test_verify_lists_mismatch():
    headers = [">seq1", ">seq2"]
    sequences = ["ATCG"]
    with pytest.raises(SystemExit):
        _verify_lists(headers, sequences)
