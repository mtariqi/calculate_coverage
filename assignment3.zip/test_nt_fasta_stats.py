import pytest
from nt_fasta_stats import get_filehandle, _get_num_nucleotides

def test_get_filehandle_OSError():
    with pytest.raises(OSError):
        get_filehandle("nonexistent_file.txt", "r")

def test_get_num_nucleotides_valid():
    sequence = "AGCTAGCTNN"
    assert _get_num_nucleotides("A", sequence) == 2
    assert _get_num_nucleotides("T", sequence) == 2

def test_get_num_nucleotides_invalid():
    sequence = "AGCTAGCTNN"
    with pytest.raises(SystemExit):
        _get_num_nucleotides("Y", sequence)
